# ScamCheck PH — Full-Power v6

**Tagline:** Before you trust it, check it.

ScamCheck PH is a mobile-first online-safety platform for checking suspicious links, phone numbers, messages, jobs, sellers, accounts, payment requests, and screenshots.

## What v6 changes

- PostgreSQL is the **actual production runtime** when `DATABASE_URL` is present. The JSON store remains available for local development.
- Auth sessions, users, scans, reports, saved checks, notifications, DeepChecks, audit logs, scam entities, and API keys use PostgreSQL in production.
- PayMongo Hosted Checkout v2 is supported for the ₱50 DeepCheck flow. A signed `checkout_session.payment.paid` webhook is the source of truth for payment fulfillment. PayMongo recommends Hosted Checkout v2 for new integrations.
- Resend transactional email is supported for production verification/reset mail.
- S3-compatible private evidence storage is supported for production uploads.
- Screenshot OCR uses Tesseract locally and is included in the Docker image.
- Production configuration validation refuses missing payment, email, database, or evidence-storage settings.
- API key authentication remains available at `POST /api/v1/check`.

## Local development

Requires Node.js 20+.

```bash
npm install
npm start
```

Open `http://localhost:3000`.

Development defaults use JSON persistence, a local evidence folder, development verification/reset tokens, and a built-in DeepCheck demo payment unless a provider is explicitly configured.

## PostgreSQL

For a real database-backed local run:

```bash
npm install
psql "$DATABASE_URL" -f db/schema.sql
npm run migrate:pg
DATABASE_URL="$DATABASE_URL" npm start
```

The production runtime automatically initializes the schema on startup after establishing the database connection. The migration script is for importing an existing JSON dataset into PostgreSQL.

## PayMongo — ₱50 DeepCheck

Set:

```env
PAYMONGO_SECRET_KEY=sk_test_...
PAYMONGO_WEBHOOK_SECRET=whsk_...
APP_BASE_URL=https://your-domain.example
PAYMONGO_PAYMENT_METHODS=gcash,paymaya,qrph,card
```

The server creates a PayMongo Hosted Checkout session on the backend, sends the customer to the returned `checkout_url`, and only marks the DeepCheck paid after a verified PayMongo webhook. Never expose the PayMongo secret key in browser code.

Register this webhook endpoint in PayMongo:

```text
POST https://your-domain.example/api/webhooks/paymongo
```

Subscribe to `checkout_session.payment.paid`. The server verifies the `Paymongo-Signature` header using the webhook secret and a five-minute replay window.

## Email — Resend

Set:

```env
EMAIL_PROVIDER=resend
RESEND_API_KEY=re_...
RESEND_FROM=ScamCheck PH <security@your-verified-domain.example>
```

Production never returns verification or reset tokens to the browser. Development may return a test token so the complete flow can be tested without a mail provider.

## Evidence storage — S3 compatible

Set:

```env
STORAGE_PROVIDER=s3
S3_BUCKET=scamcheck-evidence
S3_REGION=us-east-1
S3_ENDPOINT=
S3_FORCE_PATH_STYLE=false
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
```

Evidence files are stored outside the public web root. Use a private bucket. The code records a storage key in PostgreSQL and does not publish the object URL as public content.

## Render

`render.yaml` provisions a Node web service and Managed PostgreSQL database, and wires the required production configuration variables. Set secret values in Render for PayMongo, Resend, storage, admin credentials, and `APP_BASE_URL` before deploying.

## Production verification

```bash
npm run check
NODE_ENV=production ADMIN_EMAIL=admin@example.com ADMIN_PASSWORD='replace-with-a-unique-strong-password' \
DATABASE_URL='postgresql://...' APP_BASE_URL='https://your-domain.example' \
SESSION_SECRET='replace-with-at-least-32-random-characters' \
PAYMONGO_SECRET_KEY='sk_test_xxx' PAYMONGO_WEBHOOK_SECRET='whsk_xxx' \
EMAIL_PROVIDER=resend RESEND_API_KEY='re_xxx' RESEND_FROM='ScamCheck PH <security@example.com>' \
STORAGE_PROVIDER=s3 S3_BUCKET='scamcheck-evidence' S3_REGION='us-east-1' \
AWS_ACCESS_KEY_ID='xxx' AWS_SECRET_ACCESS_KEY='xxx' \
npm run prod:check
```

## Safety / privacy

DeepCheck is an evidence/public-information review service, not a private identity lookup or doxxing tool. Never expose passwords, OTPs, PINs, recovery codes, home addresses, or unnecessary private data. One report does not automatically prove that a person is a scammer. Serious identity findings require legitimate public evidence and human review.

## Remaining launch work

Before public launch: configure verified provider accounts, test PayMongo in test mode, register and verify the production webhook, verify the sending domain in Resend, configure private object storage and malware scanning, establish backups and monitoring, and complete the application's Philippine privacy, retention, appeal, and reporting-process review.
